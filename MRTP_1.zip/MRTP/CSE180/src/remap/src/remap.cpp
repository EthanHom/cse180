// /*
// Copyright 2023 Stefano Carpin

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

//     http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// */

// #include <rclcpp/rclcpp.hpp>
// #include <sensor_msgs/msg/laser_scan.hpp> // to receive laser scans
// #include <example_interfaces/msg/float32.hpp> // to send floating point numbers

// // publisher object to send the result
// rclcpp::Publisher<example_interfaces::msg::Float32>::SharedPtr pubf;

// // callback function called when a laser scan is received
// void processScan(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
//   example_interfaces::msg::Float32 out; // message with closest distance
//   out.data = msg->ranges[0]; // initialize result
//   // iterate over all readings and update result if necessary
//   for(unsigned int i = 1 ; i < msg->ranges.size() ; i++ ) {
//     if ( msg->ranges[i] < out.data )
//       out.data = msg->ranges[i];
//   }
//   pubf->publish(out); // publish result
// }


// int main(int argc,char ** argv) {

//   rclcpp::init(argc,argv);
//   rclcpp::Node::SharedPtr nodeh;

//   nodeh = rclcpp::Node::make_shared("pubsub"); // create node

//   // create publisher (global variable)
//   pubf = nodeh->create_publisher<example_interfaces::msg::Float32>
//                                                      ("closest",1000);
//   // create subscriber and register callback function
//   auto sub = nodeh->create_subscription<sensor_msgs::msg::LaserScan>
//     ("scan",10,&processScan);

//   rclcpp::spin(nodeh);
// }


// Claude Sonnet 4.0 Thinking
/*
Copyright 2023 Stefano Carpin

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp" // to receive and send Twist messages

// publisher object to send the remapped commands
rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_cmd;

// callback function called when a Twist message is received
void processTwist(const geometry_msgs::msg::Twist::SharedPtr msg) {
    // Simply forward the message "as is" to the new topic
    pub_cmd->publish(*msg);
}

int main(int argc, char ** argv) {
    rclcpp::init(argc, argv);
    rclcpp::Node::SharedPtr nodeh;
    nodeh = rclcpp::Node::make_shared("remap"); // create node

    // create publisher (global variable) - publishes to /cmd_vel
    pub_cmd = nodeh->create_publisher<geometry_msgs::msg::Twist>
        ("/cmd_vel", 1000);

    // create subscriber and register callback function - subscribes to turtle1/cmd_vel
    auto sub = nodeh->create_subscription<geometry_msgs::msg::Twist>
        ("turtle1/cmd_vel", 10, &processTwist);

    rclcpp::spin(nodeh);
    rclcpp::shutdown();
    return 0;
}

// end of claude sonnet 4.0 thinking



// gpt 5 thinking
/*

// src/remap.cpp
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"

class RemapNode : public rclcpp::Node {
public:
  RemapNode() : rclcpp::Node("remap") {
    pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", 10);
    sub_ = this->create_subscription<geometry_msgs::msg::Twist>(
      "turtle1/cmd_vel", 10,
      [this](const geometry_msgs::msg::Twist::SharedPtr msg) {
        pub_->publish(*msg);
      }
    );
  }
private:
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_;
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr sub_;
};

int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<RemapNode>());
  rclcpp::shutdown();
  return 0;
}


*/